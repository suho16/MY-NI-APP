package com.example.chatapp

import android.Manifest
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33)
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
                .launch(Manifest.permission.POST_NOTIFICATIONS)
        if (Repo.auth.currentUser != null) Repo.refreshToken()
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App() {
    val nav = rememberNavController()
    NavHost(nav, if (Repo.auth.currentUser != null) "chats" else "login") {
        composable("login") {
            LoginScreen { nav.navigate("chats") { popUpTo("login") { inclusive = true } } }
        }
        composable("chats") {
            ChatListScreen(
                onOpen = { id, t -> nav.navigate("chat/$id/${Uri.encode(t)}") },
                onNew = { nav.navigate("new") },
                onLogout = { Repo.signOut(); nav.navigate("login") { popUpTo("chats") { inclusive = true } } }
            )
        }
        composable("new") {
            NewChatScreen(
                onCreated = { id, t -> nav.navigate("chat/$id/${Uri.encode(t)}") { popUpTo("new") { inclusive = true } } },
                onBack = { nav.popBackStack() }
            )
        }
        composable("chat/{id}/{title}") { e ->
            ChatScreen(e.arguments!!.getString("id")!!, e.arguments!!.getString("title")!!) { nav.popBackStack() }
        }
    }
}
