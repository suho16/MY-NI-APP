package com.example.chatapp

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class FcmService : FirebaseMessagingService() {
    override fun onNewToken(token: String) { Repo.updateToken(token) }

    // 앱이 켜져 있을 때 알림 표시 (백그라운드에서는 시스템이 자동 표시)
    override fun onMessageReceived(m: RemoteMessage) {
        val n = m.notification ?: return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("chat", "메시지", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(
            System.currentTimeMillis().toInt(),
            NotificationCompat.Builder(this, "chat")
                .setSmallIcon(android.R.drawable.ic_dialog_email)
                .setContentTitle(n.title).setContentText(n.body)
                .setContentIntent(pi).setAutoCancel(true).build()
        )
    }
}
