package com.example.chatapp

import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

data class User(val uid: String, val name: String, val email: String)
data class Chat(val id: String, val members: List<String>, val group: Boolean, val name: String, val lastMessage: String, val updatedAt: Long)
data class Message(val id: String, val senderId: String, val senderName: String, val text: String, val imageUrl: String, val createdAt: Long)

object Repo {
    val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()
    val uid: String get() = auth.currentUser?.uid ?: ""
    private var nameCache: String? = null

    suspend fun signUp(name: String, email: String, pw: String) {
        val u = auth.createUserWithEmailAndPassword(email, pw).await().user!!
        db.collection("users").document(u.uid).set(mapOf("name" to name, "email" to email)).await()
        nameCache = name
        refreshToken()
    }

    suspend fun signIn(email: String, pw: String) {
        auth.signInWithEmailAndPassword(email, pw).await()
        refreshToken()
    }

    fun signOut() { auth.signOut(); nameCache = null }

    fun refreshToken() {
        FirebaseMessaging.getInstance().token.addOnSuccessListener { updateToken(it) }
    }

    fun updateToken(t: String) {
        if (uid.isNotEmpty())
            db.collection("users").document(uid).set(mapOf("fcmToken" to t), SetOptions.merge())
    }

    private suspend fun myName(): String {
        nameCache?.let { return it }
        val n = db.collection("users").document(uid).get().await().getString("name") ?: "나"
        nameCache = n
        return n
    }

    fun users(): Flow<List<User>> = callbackFlow {
        val l = db.collection("users").addSnapshotListener { s, _ ->
            trySend(s?.documents?.map { User(it.id, it.getString("name") ?: "", it.getString("email") ?: "") } ?: emptyList())
        }
        awaitClose { l.remove() }
    }

    @Suppress("UNCHECKED_CAST")
    fun chats(): Flow<List<Chat>> = callbackFlow {
        val l = db.collection("chats").whereArrayContains("members", uid).addSnapshotListener { s, _ ->
            trySend(
                s?.documents?.map {
                    Chat(
                        it.id, (it.get("members") as? List<String>) ?: emptyList(),
                        it.getBoolean("group") == true, it.getString("name") ?: "",
                        it.getString("lastMessage") ?: "", it.getLong("updatedAt") ?: 0
                    )
                }?.sortedByDescending { it.updatedAt } ?: emptyList()
            )
        }
        awaitClose { l.remove() }
    }

    suspend fun openDirect(other: String): String {
        val id = listOf(uid, other).sorted().joinToString("_")
        val ref = db.collection("chats").document(id)
        if (!ref.get().await().exists()) {
            ref.set(mapOf("members" to listOf(uid, other), "group" to false, "name" to "",
                "lastMessage" to "", "updatedAt" to System.currentTimeMillis())).await()
        }
        return id
    }

    suspend fun createGroup(name: String, others: List<String>): String {
        val ref = db.collection("chats").document()
        ref.set(mapOf("members" to (others + uid), "group" to true, "name" to name,
            "lastMessage" to "", "updatedAt" to System.currentTimeMillis())).await()
        return ref.id
    }

    fun messages(chatId: String): Flow<List<Message>> = callbackFlow {
        val l = db.collection("chats").document(chatId).collection("messages")
            .orderBy("createdAt").addSnapshotListener { s, _ ->
                trySend(s?.documents?.map {
                    Message(it.id, it.getString("senderId") ?: "", it.getString("senderName") ?: "",
                        it.getString("text") ?: "", it.getString("imageUrl") ?: "", it.getLong("createdAt") ?: 0)
                } ?: emptyList())
            }
        awaitClose { l.remove() }
    }

    suspend fun send(chatId: String, text: String, imageUrl: String = "") {
        val now = System.currentTimeMillis()
        val ref = db.collection("chats").document(chatId)
        ref.collection("messages").add(mapOf("senderId" to uid, "senderName" to myName(),
            "text" to text, "imageUrl" to imageUrl, "createdAt" to now)).await()
        ref.update(mapOf("lastMessage" to (if (imageUrl.isNotEmpty()) "📷 사진" else text), "updatedAt" to now))
    }

    suspend fun sendImage(chatId: String, uri: Uri) {
        val r = FirebaseStorage.getInstance().reference.child("chat_images/$chatId/${UUID.randomUUID()}.jpg")
        r.putFile(uri).await()
        send(chatId, "", r.downloadUrl.await().toString())
    }
}
