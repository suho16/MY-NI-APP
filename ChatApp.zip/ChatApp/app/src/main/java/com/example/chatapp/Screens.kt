package com.example.chatapp

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(onDone: () -> Unit) {
    var signUp by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center) {
        Text(if (signUp) "회원가입" else "로그인", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        if (signUp) OutlinedTextField(name, { name = it }, label = { Text("이름") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(email, { email = it }, label = { Text("이메일") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pw, { pw = it }, label = { Text("비밀번호 (6자 이상)") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        if (err.isNotEmpty()) Text(err, color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(8.dp))
        Button(
            enabled = !busy, modifier = Modifier.fillMaxWidth(),
            onClick = {
                busy = true; err = ""
                scope.launch {
                    try {
                        if (signUp) Repo.signUp(name.trim().ifBlank { "이름없음" }, email.trim(), pw)
                        else Repo.signIn(email.trim(), pw)
                        onDone()
                    } catch (e: Exception) { err = e.message ?: "실패했어요" }
                    busy = false
                }
            }
        ) { Text(if (signUp) "가입하기" else "로그인") }
        TextButton({ signUp = !signUp }) { Text(if (signUp) "이미 계정이 있어요" else "계정 만들기") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(onOpen: (String, String) -> Unit, onNew: () -> Unit, onLogout: () -> Unit) {
    val chats by remember { Repo.chats() }.collectAsState(emptyList())
    val users by remember { Repo.users() }.collectAsState(emptyList())
    Scaffold(
        topBar = { TopAppBar(title = { Text("채팅") }, actions = { TextButton(onLogout) { Text("로그아웃") } }) },
        floatingActionButton = { FloatingActionButton(onNew) { Icon(Icons.Default.Add, "새 채팅") } }
    ) { pad ->
        LazyColumn(Modifier.padding(pad)) {
            items(chats, key = { it.id }) { c ->
                val title = if (c.group) c.name
                else users.find { it.uid == c.members.firstOrNull { m -> m != Repo.uid } }?.name ?: "..."
                ListItem(
                    headlineContent = { Text(title) },
                    supportingContent = { Text(c.lastMessage, maxLines = 1) },
                    modifier = Modifier.clickable { onOpen(c.id, title) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewChatScreen(onCreated: (String, String) -> Unit, onBack: () -> Unit) {
    val users by remember { Repo.users() }.collectAsState(emptyList())
    var sel by remember { mutableStateOf(setOf<String>()) }
    var gname by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    Scaffold(topBar = {
        TopAppBar(title = { Text("새 채팅 (1명=1:1, 2명 이상=그룹)") },
            navigationIcon = { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "뒤로") } })
    }) { pad ->
        Column(Modifier.padding(pad)) {
            LazyColumn(Modifier.weight(1f)) {
                items(users.filter { it.uid != Repo.uid }, key = { it.uid }) { u ->
                    ListItem(
                        headlineContent = { Text(u.name) },
                        supportingContent = { Text(u.email) },
                        trailingContent = { Checkbox(u.uid in sel, null) },
                        modifier = Modifier.clickable { sel = if (u.uid in sel) sel - u.uid else sel + u.uid }
                    )
                }
            }
            if (sel.size >= 2) OutlinedTextField(gname, { gname = it }, label = { Text("그룹 이름") },
                modifier = Modifier.fillMaxWidth().padding(8.dp))
            if (sel.isNotEmpty()) Button(
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                onClick = {
                    scope.launch {
                        if (sel.size == 1) {
                            val o = users.first { it.uid == sel.first() }
                            onCreated(Repo.openDirect(o.uid), o.name)
                        } else {
                            val n = gname.ifBlank { "그룹 채팅" }
                            onCreated(Repo.createGroup(n, sel.toList()), n)
                        }
                    }
                }
            ) { Text(if (sel.size == 1) "1:1 채팅 시작" else "그룹 만들기") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(chatId: String, title: String, onBack: () -> Unit) {
    val msgs by remember { Repo.messages(chatId) }.collectAsState(emptyList())
    var text by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        if (uri != null) scope.launch { runCatching { Repo.sendImage(chatId, uri) } }
    }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex) }
    Scaffold(topBar = {
        TopAppBar(title = { Text(title) }, navigationIcon = { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "뒤로") } })
    }) { pad ->
        Column(Modifier.padding(pad)) {
            LazyColumn(
                Modifier.weight(1f).padding(horizontal = 8.dp), state = listState,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(msgs, key = { it.id }) { m ->
                    val mine = m.senderId == Repo.uid
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                        if (!mine) Text(m.senderName, style = MaterialTheme.typography.labelSmall)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (mine) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            if (m.imageUrl.isNotEmpty())
                                AsyncImage(m.imageUrl, null, Modifier.size(200.dp), contentScale = ContentScale.Crop)
                            else Text(m.text, Modifier.padding(10.dp))
                        }
                    }
                }
            }
            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton({ picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("📷") }
                OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("메시지") }, maxLines = 4)
                IconButton({
                    if (text.isNotBlank()) { val t = text.trim(); text = ""; scope.launch { Repo.send(chatId, t) } }
                }) { Icon(Icons.Default.Send, "보내기") }
            }
        }
    }
}
