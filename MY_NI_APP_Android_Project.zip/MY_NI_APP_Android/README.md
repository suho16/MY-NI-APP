# MY NI APP — Android APK project (v1.0.0)

This is an Android WebView app containing the current MY NI APP v1.4 HTML interface. It preserves the app's local WebView storage on the same device and checks a hosted JSON manifest for newer APK versions.

## Important status
- This package is an **Android source project**, not an APK. It has not been compiled or device-tested in this environment.
- The current signup/login screen inside the bundled HTML is a local demo account, not secure cloud authentication. It stores account details in the device browser storage. Do not use a real password. For real multi-device accounts, integrate Firebase Authentication + Firestore before public release.
- The updater is implemented but will not find updates until you configure the GitHub URL, publish a signed APK, and host `update/version.json` at that URL.
- Android always requires user confirmation to install an APK update. This app cannot silently install itself.

## 1. Create a permanent signing key (one time)
Use Android Studio's Generate Signed Bundle/APK wizard or `keytool` to create one release keystore. Keep it safe. Every future APK update **must use the same keystore** or Android will refuse the update. Never upload the keystore to a public repository.

## 2. Configure the updater URL
Edit `app/src/main/java/com/myniapp/app/MainActivity.kt` and replace:
`https://raw.githubusercontent.com/REPLACE_OWNER/REPLACE_REPO/main/update/version.json`
with your GitHub raw URL.
Also edit `update/version.json` and replace the repository placeholders in `apkUrl`.

## 3. GitHub Actions secrets
Create these repository secrets:
- `KEYSTORE_BASE64`: base64 text of your release `.jks` file
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`

Then run Actions → Build signed MY NI APP APK. Download the artifact `MY_NI_APP-release-apk`, publish it as a GitHub Release asset named `MY_NI_APP.apk`, and update `update/version.json` with a higher `versionCode`, new `versionName`, and the release APK URL. Commit/push the updated manifest.

## 4. Release versioning
For every update:
1. Change `versionCode` in `app/build.gradle.kts` to a larger integer.
2. Change `currentVersionCode` in `MainActivity.kt` to the same integer.
3. Change `versionCode` and `versionName` in `update/version.json`.
4. Run the signed GitHub Actions workflow again with the same signing key.
5. Replace the GitHub Release APK asset and commit the new manifest.

## 5. Install
Install the signed APK on Android. On first update, Android may ask you to allow this app to install unknown apps. The user must approve the system installer prompt.

## Build locally
Open this folder in Android Studio, sync Gradle, and build the release APK using your release keystore. This project uses package name `com.myniapp.app`.
