package com.myniapp.app

import android.app.Activity
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
    // 배포 전 GitHub 사용자명/저장소명으로 바꿔야 합니다.
    private val updateManifestUrl = "https://raw.githubusercontent.com/REPLACE_OWNER/REPLACE_REPO/main/update/version.json"
    private val currentVersionCode = 1
    private lateinit var webView: WebView
    private lateinit var updateText: TextView
    private lateinit var updateButton: Button
    private var latestApkUrl: String? = null
    private var downloadedApkId: Long = -1L

    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) == downloadedApkId) {
                installDownloadedApk()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        val updateBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 8, 12, 8)
            setBackgroundColor(android.graphics.Color.rgb(28, 28, 28))
        }
        updateText = TextView(this).apply {
            text = "MY NI APP · 최신 버전 확인 중"
            setTextColor(android.graphics.Color.WHITE)
            textSize = 12f
        }
        updateButton = Button(this).apply {
            text = "업데이트"
            visibility = View.GONE
            setOnClickListener { downloadUpdate() }
        }
        updateBar.addView(updateText, LinearLayout.LayoutParams(0, -2, 1f))
        updateBar.addView(updateButton)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            loadUrl("file:///android_asset/index.html")
        }
        root.addView(updateBar)
        root.addView(webView, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (android.os.Build.VERSION.SDK_INT >= 33) registerReceiver(downloadReceiver, filter, RECEIVER_NOT_EXPORTED)
        else registerReceiver(downloadReceiver, filter)
        checkForUpdate()
    }

    private fun checkForUpdate() {
        Thread {
            try {
                val connection = (URL(updateManifestUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                }
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                val json = JSONObject(body)
                val remoteCode = json.optInt("versionCode", 0)
                val remoteName = json.optString("versionName", "새 버전")
                val apk = json.optString("apkUrl", "")
                runOnUiThread {
                    if (remoteCode > currentVersionCode && apk.startsWith("https://")) {
                        latestApkUrl = apk
                        updateText.text = "새 버전 $remoteName 을(를) 사용할 수 있어요."
                        updateButton.visibility = View.VISIBLE
                    } else {
                        updateText.text = "MY NI APP · 최신 버전 사용 중"
                        updateButton.visibility = View.GONE
                    }
                }
            } catch (_: Exception) {
                runOnUiThread { updateText.text = "업데이트 확인을 건너뛰었어요." }
            }
        }.start()
    }

    private fun downloadUpdate() {
        val url = latestApkUrl ?: return
        try {
            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle("MY NI APP 업데이트")
                .setDescription("새 버전을 다운로드하고 있어요.")
                .setMimeType("application/vnd.android.package-archive")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "MY_NI_APP_update.apk")
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
            downloadedApkId = (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            updateText.text = "업데이트 다운로드 중..."
            updateButton.isEnabled = false
        } catch (_: Exception) {
            Toast.makeText(this, "업데이트 다운로드를 시작하지 못했어요.", Toast.LENGTH_LONG).show()
            updateButton.isEnabled = true
        }
    }

    private fun installDownloadedApk() {
        updateButton.isEnabled = true
        val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        val uri = manager.getUriForDownloadedFile(downloadedApkId)
        if (uri == null) {
            updateText.text = "다운로드에 실패했어요. 다시 시도해 주세요."
            return
        }
        if (android.os.Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            val settingsIntent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            startActivity(settingsIntent)
            Toast.makeText(this, "MY NI APP의 알 수 없는 앱 설치를 허용한 뒤 다운로드 파일을 눌러 설치해 주세요.", Toast.LENGTH_LONG).show()
            updateText.text = "설치 권한을 허용한 뒤 다운로드 폴더에서 업데이트 파일을 열어 주세요."
            return
        }
        val install = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(install) }
        catch (_: Exception) { updateText.text = "다운로드 폴더에서 MY_NI_APP_update.apk를 열어 설치해 주세요." }
    }

    override fun onDestroy() {
        try { unregisterReceiver(downloadReceiver) } catch (_: Exception) {}
        webView.destroy()
        super.onDestroy()
    }
}
